#  It is a minimal receicer with two push buttons

This sketch illustrates a minimalist implementation of a receiver based on RDA5807 and this library.
For this receiver, the user has two pushbuttons to tune station (Seek Up and Seek Down). See the schematic below.


## Minimalist receiver based on RDA5807 circuit

![Minimalist receiver based on RDA5807](../../extras/images/minimalist_receiver_circuit.png)



## Viedo

[MINIMALIST RECEIVER WITH RDA5807 ARDUINO LIBRARY](https://youtu.be/C-wlpbgniLY)


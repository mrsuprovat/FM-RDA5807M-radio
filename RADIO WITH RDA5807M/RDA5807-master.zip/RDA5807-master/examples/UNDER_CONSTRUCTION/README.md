# UNDER CONSTRUCTION SKETCHES

This folder has some sketches under construction. 

![Under construction...](../../extras/images/under_construction.png)




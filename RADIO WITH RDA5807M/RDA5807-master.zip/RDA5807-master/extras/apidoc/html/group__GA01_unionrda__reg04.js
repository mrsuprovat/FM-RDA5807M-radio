var group__GA01_unionrda__reg04 =
[
    [ "raw", "group__GA01.html#a5c872e111c0fbaf477625700a2076359", null ],
    [ "refined", "group__GA01.html#af1c6e72539ee65749eb0f049303ad616", null ]
];
var group___g_a01_unionrda__reg04 =
[
    [ "refined", "group___g_a01.html#af1c6e72539ee65749eb0f049303ad616", null ],
    [ "raw", "group___g_a01.html#a5c872e111c0fbaf477625700a2076359", null ]
];
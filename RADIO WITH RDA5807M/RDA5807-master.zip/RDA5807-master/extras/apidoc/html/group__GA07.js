var group__GA07 =
[
    [ "RDA5807::getBass", "group__GA07.html#ga49e08eb54c1e235bd7516c552dee1320", null ],
    [ "RDA5807::getMute", "group__GA07.html#gaf488f0fdb96addfa014ce05e977b8a52", null ],
    [ "RDA5807::getVolume", "group__GA07.html#ga743d91d820922b3feda10d06443bc8a9", null ],
    [ "RDA5807::isAudioOutputHighImpedance", "group__GA07.html#ga5195195da106c05f29218910b17f6f6b", null ],
    [ "RDA5807::isMuted", "group__GA07.html#gaef3ebf331e0646a67b6ebfa6d47c3a16", null ],
    [ "RDA5807::isSoftmuted", "group__GA07.html#ga428ddd720c58c17273322d7526e51cbe", null ],
    [ "RDA5807::isStereo", "group__GA07.html#ga250ff3788a7831dae3c6200919b446dd", null ],
    [ "RDA5807::setAudioOutputHighImpedance", "group__GA07.html#gaabd554f39778bf6d81712df0ea72d0fa", null ],
    [ "RDA5807::setBass", "group__GA07.html#ga8002bb394ef19db02e04a39de04dffc5", null ],
    [ "RDA5807::setLedStereoIndicator", "group__GA07.html#ga7955280c2b3a9b5e7336fc3862133b39", null ],
    [ "RDA5807::setMono", "group__GA07.html#gad6e77ffbeb3f4dc885548130e09590d6", null ],
    [ "RDA5807::setMute", "group__GA07.html#gafec3018913d735ee0684b88cf503c84a", null ],
    [ "RDA5807::setSoftmute", "group__GA07.html#gadd2c2ab8b861ab0714fdeb99c774d656", null ],
    [ "RDA5807::setVolume", "group__GA07.html#ga51bf4344ebeb44f7170265901df870f5", null ],
    [ "RDA5807::setVolumeDown", "group__GA07.html#ga910965f74897b0246a0b3bed39743d8c", null ],
    [ "RDA5807::setVolumeUp", "group__GA07.html#ga864af32df4d3365e03f8876703218283", null ]
];
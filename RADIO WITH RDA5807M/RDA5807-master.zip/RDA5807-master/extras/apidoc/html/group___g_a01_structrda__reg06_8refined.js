var group___g_a01_structrda__reg06_8refined =
[
    [ "R_DELY", "group___g_a01.html#a575d0f8dbbda12d743c6cbd80436d8d2", null ],
    [ "L_DELY", "group___g_a01.html#a4ce1c95146a332f39eb691cbc95ccbb2", null ],
    [ "SCLK_O_EDGE", "group___g_a01.html#a3f5cd3a22eb13c67f7d20adcd15f1ad1", null ],
    [ "SW_O_EDGE", "group___g_a01.html#a90f7e01cd9d2f78095b8d23a9dc1b18d", null ],
    [ "I2S_SW_CNT", "group___g_a01.html#afbff3a29529e5e3276e2bebab1f15a3f", null ],
    [ "WS_I_EDGE", "group___g_a01.html#ab5e655121ad945deced0a44ac51ad7c9", null ],
    [ "DATA_SIGNED", "group___g_a01.html#ac20607bab830e003f8aef1927f30da81", null ],
    [ "SCLK_I_EDGE", "group___g_a01.html#ab0a4aea0751fa685c79ed52660ad78fb", null ],
    [ "WS_LR", "group___g_a01.html#a8f48ecc038b447fc3a713924344e8094", null ],
    [ "SLAVE_MASTER", "group___g_a01.html#a5b44678fa097828236f91b766d1bca94", null ],
    [ "OPEN_MODE", "group___g_a01.html#a6e2ac78f66cfafa9ecf1b7e62f037b43", null ],
    [ "RSVD", "group___g_a01.html#ae57526e5b56fb9372080178384f4c872", null ]
];
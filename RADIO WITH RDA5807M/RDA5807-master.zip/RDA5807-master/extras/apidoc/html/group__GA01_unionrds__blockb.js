var group__GA01_unionrds__blockb =
[
    [ "blockB", "group__GA01.html#a5dae9f2b7edfd4dff7592ed38e403344", null ],
    [ "group0", "group__GA01.html#ac5781cba2e954484c72ae3077e25afcf", null ],
    [ "group2", "group__GA01.html#a0a430ac426505b17010fe872dba656a8", null ],
    [ "refined", "group__GA01.html#ab34c18f5ea4466a422f8370757d4fcbc", null ]
];
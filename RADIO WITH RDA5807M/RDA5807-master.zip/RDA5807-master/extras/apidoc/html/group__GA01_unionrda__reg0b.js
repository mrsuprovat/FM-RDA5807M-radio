var group__GA01_unionrda__reg0b =
[
    [ "raw", "group__GA01.html#a025a972ff39a3584183e12de290d0fb6", null ],
    [ "refined", "group__GA01.html#a0eeacb17a43648ed4c922fb16253fa5c", null ]
];
var group___g_a01_unionrda__reg06 =
[
    [ "refined", "group___g_a01.html#a360eecf942f40d3f51812293e76a0d67", null ],
    [ "raw", "group___g_a01.html#a6821afdfb5ab6f0a279ef1c4fdeaa9e1", null ]
];
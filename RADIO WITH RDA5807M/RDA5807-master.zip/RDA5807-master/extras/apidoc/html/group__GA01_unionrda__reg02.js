var group__GA01_unionrda__reg02 =
[
    [ "raw", "group__GA01.html#a1a250acebf8f445cc5b685da35ae2b7a", null ],
    [ "refined", "group__GA01.html#a1809838a4ec469d3ff1eeb7dacb89252", null ]
];
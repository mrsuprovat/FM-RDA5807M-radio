var group__GA08 =
[
    [ "RDA5807::getLnaIcSel", "group__GA08.html#gacdf40b2507df37ef2f7cbed8c12c68f7", null ],
    [ "RDA5807::getLnaPortSel", "group__GA08.html#gafa3762b30fbf95bd6bb04139faed47c6", null ],
    [ "RDA5807::getRssi", "group__GA08.html#ga4bd7597d4c9090b04486aec21a6a0a5d", null ],
    [ "RDA5807::setLnaIcSel", "group__GA08.html#ga35428e147462af6490c382acdf769173", null ],
    [ "RDA5807::setLnaPortSel", "group__GA08.html#gaf595aab626e55ab733af8682674faa61", null ]
];
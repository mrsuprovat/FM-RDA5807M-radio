var group__GA01_unionrda__reg07 =
[
    [ "raw", "group__GA01.html#a2dacd798a51d8fc4effa015d9d16c1a0", null ],
    [ "refined", "group__GA01.html#ac5c4daceecb405708b96c79b477db70b", null ]
];
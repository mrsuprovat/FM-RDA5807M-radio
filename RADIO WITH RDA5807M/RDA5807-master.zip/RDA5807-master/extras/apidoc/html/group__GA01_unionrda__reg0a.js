var group__GA01_unionrda__reg0a =
[
    [ "raw", "group__GA01.html#a4739c58f7e2dcffa54e2368e98716e99", null ],
    [ "refined", "group__GA01.html#ac3a52ed2e4783d2bb7c1e82716c98af3", null ]
];
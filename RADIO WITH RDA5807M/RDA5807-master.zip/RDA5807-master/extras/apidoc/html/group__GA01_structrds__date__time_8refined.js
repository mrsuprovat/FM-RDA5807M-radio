var group__GA01_structrds__date__time_8refined =
[
    [ "hour", "group__GA01.html#a896c55cc5e46fab38ce9f51ebf7bfcd3", null ],
    [ "minute", "group__GA01.html#a0a7d55be9d12a369a6a8da0fb517fba4", null ],
    [ "mjd", "group__GA01.html#a7f7685b39180278dd0fa69f523c7bd24", null ],
    [ "offset", "group__GA01.html#a7a86c157ee9713c34fbd7a1ee40f0c5a", null ],
    [ "offset_sense", "group__GA01.html#a5ba6e404c489ff4f757e7c77cb9fa310", null ]
];
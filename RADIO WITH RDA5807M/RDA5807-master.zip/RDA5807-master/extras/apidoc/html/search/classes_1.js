var searchData=
[
  ['word16_5fto_5fbytes_0',['word16_to_bytes',['../group__GA01.html#unionword16__to__bytes',1,'']]],
  ['word16_5fto_5fbytes_2erefined_1',['word16_to_bytes.refined',['../group__GA01.html#structword16__to__bytes_8refined',1,'']]]
];

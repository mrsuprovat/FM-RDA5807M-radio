var searchData=
[
  ['oldtextabflag_0',['oldTextABFlag',['../group__GA01.html#ae83461389f706c7a27512e5e08655f1b',1,'RDA5807']]],
  ['oscillatortype_1',['oscillatorType',['../group__GA01.html#a4c8780f2d28725d66850f9e3be14745a',1,'RDA5807']]]
];

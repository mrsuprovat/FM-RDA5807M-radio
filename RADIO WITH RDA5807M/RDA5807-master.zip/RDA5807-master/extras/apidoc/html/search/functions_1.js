var searchData=
[
  ['formatcurrentfrequency_0',['formatCurrentFrequency',['../group__G05.html#ga43c6c86481dd1fdba0fc14438bc8e18e',1,'RDA5807']]],
  ['formatfrequency_1',['formatFrequency',['../group__G05.html#ga2275869d5ec1bd0eaea2e278e2a70cc7',1,'RDA5807']]]
];

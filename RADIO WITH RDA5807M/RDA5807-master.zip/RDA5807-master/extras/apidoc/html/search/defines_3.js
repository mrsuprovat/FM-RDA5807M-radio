var searchData=
[
  ['oscillator_5ftype_5factive_0',['OSCILLATOR_TYPE_ACTIVE',['../RDA5807_8h.html#a6231498726197328216bb70c6dfc21aa',1,'RDA5807.h']]],
  ['oscillator_5ftype_5fcrystal_1',['OSCILLATOR_TYPE_CRYSTAL',['../RDA5807_8h.html#ad0763fd256db4ec1ecc62f84bbff56e2',1,'RDA5807.h']]],
  ['oscillator_5ftype_5fpassive_2',['OSCILLATOR_TYPE_PASSIVE',['../RDA5807_8h.html#a0941eab712587842e5513eb6cd562717',1,'RDA5807.h']]],
  ['oscillator_5ftype_5frefclk_3',['OSCILLATOR_TYPE_REFCLK',['../RDA5807_8h.html#ad079e38ccae2f64aa341332e2ccb8b8e',1,'RDA5807.h']]]
];

var searchData=
[
  ['oldtextabflag_0',['oldTextABFlag',['../group__GA01.html#ae83461389f706c7a27512e5e08655f1b',1,'RDA5807']]],
  ['oscillator_5ftype_5factive_1',['OSCILLATOR_TYPE_ACTIVE',['../RDA5807_8h.html#a6231498726197328216bb70c6dfc21aa',1,'RDA5807.h']]],
  ['oscillator_5ftype_5fcrystal_2',['OSCILLATOR_TYPE_CRYSTAL',['../RDA5807_8h.html#ad0763fd256db4ec1ecc62f84bbff56e2',1,'RDA5807.h']]],
  ['oscillator_5ftype_5fpassive_3',['OSCILLATOR_TYPE_PASSIVE',['../RDA5807_8h.html#a0941eab712587842e5513eb6cd562717',1,'RDA5807.h']]],
  ['oscillator_5ftype_5frefclk_4',['OSCILLATOR_TYPE_REFCLK',['../RDA5807_8h.html#ad079e38ccae2f64aa341332e2ccb8b8e',1,'RDA5807.h']]],
  ['oscillatortype_5',['oscillatorType',['../group__GA01.html#a4c8780f2d28725d66850f9e3be14745a',1,'RDA5807']]]
];

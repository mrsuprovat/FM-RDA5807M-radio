var searchData=
[
  ['deviceaddressdirectaccess_0',['deviceAddressDirectAccess',['../group__GA01.html#a18c3e5a103b683af7c46d8b9a3d47518',1,'RDA5807']]],
  ['deviceaddressfullaccess_1',['deviceAddressFullAccess',['../group__GA01.html#a81c00f45187f93be0698ef8c5bd80619',1,'RDA5807']]],
  ['directfrequency_2',['directFrequency',['../group__GA01.html#a7ca80902d2748f8f0dca2edafafdeebe',1,'rda_reg08']]]
];

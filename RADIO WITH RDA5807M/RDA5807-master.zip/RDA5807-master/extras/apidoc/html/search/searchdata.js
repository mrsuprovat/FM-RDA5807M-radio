var indexSectionsWithContent =
{
  0: "abcdefghilmoprstuw",
  1: "rw",
  2: "r",
  3: "cfghipsw",
  4: "bcdefgmors",
  5: "cimors",
  6: "abfilrtu",
  7: "rt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Modules",
  7: "Pages"
};


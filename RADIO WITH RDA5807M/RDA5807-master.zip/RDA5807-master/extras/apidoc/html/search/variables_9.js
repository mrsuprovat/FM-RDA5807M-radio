var searchData=
[
  ['shadowregisters_0',['shadowRegisters',['../group__GA01.html#ae9572809d64fc5c82f95d4f26d5c308d',1,'RDA5807']]],
  ['shadowstatusregisters_1',['shadowStatusRegisters',['../group__GA01.html#ae51bb0aaf958ee320da80866bb20ffb5',1,'RDA5807']]],
  ['startband_2',['startBand',['../group__GA01.html#acddb5bea9e4872e9aecf4dc9bd89a1e6',1,'RDA5807']]],
  ['strfrequency_3',['strFrequency',['../group__GA01.html#a7f1dad9330a21ce952c91d55ef8e2ad0',1,'RDA5807']]]
];

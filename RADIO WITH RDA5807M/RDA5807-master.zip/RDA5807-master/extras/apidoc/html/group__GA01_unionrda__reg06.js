var group__GA01_unionrda__reg06 =
[
    [ "raw", "group__GA01.html#a6821afdfb5ab6f0a279ef1c4fdeaa9e1", null ],
    [ "refined", "group__GA01.html#a360eecf942f40d3f51812293e76a0d67", null ]
];
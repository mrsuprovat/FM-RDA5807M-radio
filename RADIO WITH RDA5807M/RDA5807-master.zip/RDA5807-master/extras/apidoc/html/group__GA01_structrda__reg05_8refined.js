var group__GA01_structrda__reg05_8refined =
[
    [ "INT_MODE", "group__GA01.html#a54e8dc27cd18af681fec547952404531", null ],
    [ "LNA_ICSEL_BIT", "group__GA01.html#a160505dce0d227e0f21232f52fef890f", null ],
    [ "LNA_PORT_SEL", "group__GA01.html#a11b8f14c44524bb37f0a89d4b5559a94", null ],
    [ "RSVD2", "group__GA01.html#a8d50eb6e30711e4eb7625e651ed1a11d", null ],
    [ "SEEK_MODE", "group__GA01.html#ac34168e070146678d72546abc1c8b236", null ],
    [ "SEEKTH", "group__GA01.html#a991f75a1bf4d56192acecdf31ad3db47", null ],
    [ "VOLUME", "group__GA01.html#a730956af87021c351084317bbc63eea6", null ]
];
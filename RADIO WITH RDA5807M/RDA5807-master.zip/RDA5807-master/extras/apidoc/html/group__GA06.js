var group__GA06 =
[
    [ "RDA5807::setI2SAllParameters", "group__GA06.html#ga2070bff9af95a523a77ac304eee7b22f", null ],
    [ "RDA5807::setI2SDataSigned", "group__GA06.html#gabeb9446fc371fe58e075bea7ebc51fdb", null ],
    [ "RDA5807::setI2SMaster", "group__GA06.html#ga70f086ccb3be49c4c51133bae2e8b113", null ],
    [ "RDA5807::setI2SOn", "group__GA06.html#gafe324014c135a510714e7d722f291273", null ],
    [ "RDA5807::setI2SSpeed", "group__GA06.html#ga3d5618cd755c0a56fea68ea589bb828f", null ]
];
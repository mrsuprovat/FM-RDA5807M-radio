var group__GA01_unionrds__date__time =
[
    [ "raw", "group__GA01.html#abb6c459455299730ef24dc149a871202", null ],
    [ "refined", "group__GA01.html#a9bcded0e419c611d9920953260c352cb", null ]
];
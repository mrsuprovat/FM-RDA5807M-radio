var group__GA01_unionrda__reg0f =
[
    [ "RDSD", "group__GA01.html#a468a600809a23e18a9b40dadccfd3740", null ],
    [ "refined", "group__GA01.html#a2277c8c28e92e2ad993af1c0c5fb4c94", null ]
];
var group___g_a01_structrda__reg0a_8refined =
[
    [ "READCHAN", "group___g_a01.html#abe63df93c3d4af07359a55d5902f0f7a", null ],
    [ "ST", "group___g_a01.html#aec8e57d71f07e31203035548b79d03c8", null ],
    [ "BLK_E", "group___g_a01.html#a3c723083c9b52fde34d2c4beb725942f", null ],
    [ "RDSS", "group___g_a01.html#a3928b702beefaf125960c8f1f7fceac7", null ],
    [ "SF", "group___g_a01.html#a94a990462684a2fbb5dfc7fab1c8975d", null ],
    [ "STC", "group___g_a01.html#a3a247d1d806ebfcd27b09041e3186b4e", null ],
    [ "RDSR", "group___g_a01.html#accd030164321bb71a36d491b2e6cd424", null ]
];
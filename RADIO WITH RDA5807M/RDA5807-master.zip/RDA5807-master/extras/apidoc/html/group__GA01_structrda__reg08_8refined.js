var group__GA01_structrda__reg08_8refined =
[
    [ "highByte", "group__GA01.html#a7b99e4a5dc723242645ede8c604610df", null ],
    [ "lowByte", "group__GA01.html#a51ab88497cad20027df936afa223b23d", null ]
];
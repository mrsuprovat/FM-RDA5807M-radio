var modules =
[
    [ "Audio Functions", "group__GA07.html", "group__GA07" ],
    [ "Basic Functions", "group__GA02.html", "group__GA02" ],
    [ "FM Tune Functions", "group__GA03.html", "group__GA03" ],
    [ "I2S Functions", "group__GA06.html", "group__GA06" ],
    [ "LNA setup and Signal status", "group__GA08.html", "group__GA08" ],
    [ "RDS Functions", "group__GA04.html", "group__GA04" ],
    [ "Tools method", "group__G05.html", "group__G05" ],
    [ "Union, Structure and Defined Data Types", "group__GA01.html", "group__GA01" ]
];
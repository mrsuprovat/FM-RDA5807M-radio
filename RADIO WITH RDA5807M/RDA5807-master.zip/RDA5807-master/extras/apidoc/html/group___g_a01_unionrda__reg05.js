var group___g_a01_unionrda__reg05 =
[
    [ "refined", "group___g_a01.html#ad2153e9e90608e267b44117ececc5783", null ],
    [ "raw", "group___g_a01.html#aaa18c311f81277e3d73436ea0b601bb1", null ]
];
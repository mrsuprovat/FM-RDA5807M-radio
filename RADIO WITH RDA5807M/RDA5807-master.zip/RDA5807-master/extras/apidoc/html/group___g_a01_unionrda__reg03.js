var group___g_a01_unionrda__reg03 =
[
    [ "refined", "group___g_a01.html#a8a7bf8e4ddb7f76cbafe53ba366d04ca", null ],
    [ "raw", "group___g_a01.html#a896ca93bb7040c45cbf062396d40ebca", null ]
];
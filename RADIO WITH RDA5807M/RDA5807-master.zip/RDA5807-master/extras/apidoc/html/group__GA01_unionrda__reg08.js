var group__GA01_unionrda__reg08 =
[
    [ "directFrequency", "group__GA01.html#a7ca80902d2748f8f0dca2edafafdeebe", null ],
    [ "refined", "group__GA01.html#a6b901f2c85429c6822d5e8dc19d1c780", null ]
];
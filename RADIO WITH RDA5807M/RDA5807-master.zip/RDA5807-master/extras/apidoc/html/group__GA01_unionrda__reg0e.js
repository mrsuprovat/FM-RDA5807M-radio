var group__GA01_unionrda__reg0e =
[
    [ "RDSC", "group__GA01.html#a519e4146ff314e51a19f354ec7f07b8e", null ],
    [ "refined", "group__GA01.html#a63c425b6b07f0604a43481f0312d3d59", null ]
];
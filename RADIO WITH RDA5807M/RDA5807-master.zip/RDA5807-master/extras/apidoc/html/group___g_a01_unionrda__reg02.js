var group___g_a01_unionrda__reg02 =
[
    [ "refined", "group___g_a01.html#a1809838a4ec469d3ff1eeb7dacb89252", null ],
    [ "raw", "group___g_a01.html#a1a250acebf8f445cc5b685da35ae2b7a", null ]
];
var group__GA01_structrda__reg03_8refined =
[
    [ "BAND", "group__GA01.html#aa8a5bbeedca093b94b7f0d3f185b98f7", null ],
    [ "CHAN", "group__GA01.html#adf21771052967392286eeab054755423", null ],
    [ "DIRECT_MODE", "group__GA01.html#a799f81e68cf18ca017f69d9405267e41", null ],
    [ "SPACE", "group__GA01.html#a6506ae39fdca9845e3a6de3865183e57", null ],
    [ "TUNE", "group__GA01.html#a05069c0e15b79590b44ff985487037b7", null ]
];
var group__GA01_unionrda__reg00 =
[
    [ "raw", "group__GA01.html#a4032484c615397b498d1af01aa1d1453", null ],
    [ "refined", "group__GA01.html#ac5a1a7191e10e3c1d300537387e6acbc", null ]
];
var group__GA01_unionrda__reg01 =
[
    [ "raw", "group__GA01.html#a5753f7265ef5b1291ff160c431ebe863", null ],
    [ "refined", "group__GA01.html#a95db31874aa1c376e10041fbf4c04bd0", null ]
];
var group__GA01_unionrda__reg03 =
[
    [ "raw", "group__GA01.html#a896ca93bb7040c45cbf062396d40ebca", null ],
    [ "refined", "group__GA01.html#a8a7bf8e4ddb7f76cbafe53ba366d04ca", null ]
];
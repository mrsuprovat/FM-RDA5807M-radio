var group__GA02 =
[
    [ "RDA5807::getDeviceId", "group__GA02.html#gad1d589d43adc89a93c5e07b2d4cb6a4c", null ],
    [ "RDA5807::getDirectRegister", "group__GA02.html#ga69981ef141e22ab00e4bde3f18f84964", null ],
    [ "RDA5807::getStatus", "group__GA02.html#ga1f4bc3d6f9d94171b2965dbb4e812f4f", null ],
    [ "RDA5807::getStatusRegisters", "group__GA02.html#gab9e3a5584a6238f719e9c9e49435f5ce", null ],
    [ "RDA5807::powerDown", "group__GA02.html#ga214f631aef72ece69db73c99879c7c46", null ],
    [ "RDA5807::powerUp", "group__GA02.html#ga30d2b0c4662922df53bcef118663329c", null ],
    [ "RDA5807::setDelayAfterCrystalOn", "group__GA02.html#ga1db36d126d26a553668c1b70de9b3823", null ],
    [ "RDA5807::setGpio", "group__GA02.html#ga677eff1084b294696a32e3ca4dfe593b", null ],
    [ "RDA5807::setI2CBusAddrs", "group__GA02.html#gadf634cb6733022e30d8f1a74a5946e78", null ],
    [ "RDA5807::setInterruptMode", "group__GA02.html#gabd676c0e4ad20c6152a68f8daba64cb3", null ],
    [ "RDA5807::setNewDemodulateMethod", "group__GA02.html#gab97c1c8ad3ab0cd5d2852f712caee0a1", null ],
    [ "RDA5807::setRegister", "group__GA02.html#ga3b581b82ab8c631cfec537a47008ddf3", null ],
    [ "RDA5807::setup", "group__GA02.html#ga272444216a784ea5317c83783eb2bfe7", null ],
    [ "RDA5807::softReset", "group__GA02.html#ga3f6dace4c93f82ec66da5641e3e3fdaa", null ],
    [ "RDA5807::waitAndFinishTune", "group__GA02.html#ga3fe1feed45d3290beba0efef491128e6", null ]
];
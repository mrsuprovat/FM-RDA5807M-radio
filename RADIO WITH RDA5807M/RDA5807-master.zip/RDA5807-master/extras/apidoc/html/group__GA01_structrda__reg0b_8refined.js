var group__GA01_structrda__reg0b_8refined =
[
    [ "ABCD_E", "group__GA01.html#a297000d9caac4f06fe67d8972202b2f8", null ],
    [ "BLERA", "group__GA01.html#a5cf5d2b056255cb2235ce6c52c0e9795", null ],
    [ "BLERB", "group__GA01.html#abf73094dcea591929f5c4ffe912d6750", null ],
    [ "FM_READY", "group__GA01.html#a7b86ad4e3ff3b175ed1b73968c43140f", null ],
    [ "FM_TRUE", "group__GA01.html#aa792520704f786ade70d6a06b6b8ba34", null ],
    [ "RSSI", "group__GA01.html#a6833f5d3374c1679bea428b50dbad9cc", null ],
    [ "RSVD1", "group__GA01.html#a1742cf1b14a750532e645aab85933d3c", null ]
];
var group___g_a01_structrda__reg00_8refined =
[
    [ "LOW_CHIP_ID", "group___g_a01.html#ab1408e92ecfc268499c1ff228bf815b2", null ],
    [ "HIGH_CHIP_ID", "group___g_a01.html#ae9ab18e96e3a6f4d4f9ade0ea0501da4", null ]
];